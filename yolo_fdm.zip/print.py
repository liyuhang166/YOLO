import numpy as np
import cv2 as cv
import os
import random

file = r'C:/Users/Lee/Desktop/train_update/img_clean/clean/'

for file_img in os.listdir(file):  # 需要处理的文件夹
    img = cv.imread(file + file_img)  # 需要处理的文件夹
    mask_img = cv.imread(file + file_img)  # 需要处理的文件夹
    # mask_img=np.zeros((img.shape[1], img.shape[0]), dtype=np.uint8)
    # mask_img[:, :] = (144, 128, 112)  # 112, 128, 144 RGB
    mask_img[:, :] = (166, 178, 180)  # 雾的颜色
    # cv.imwrite('./rtimg.jpg', mask_img)
    # area = [[0, 0], [0, img.shape[0]], [img.shape[1], img.shape[0]], [img.shape[1], 0]]
    # mask_img = cv.fillConvexPoly(mask_img, np.array(area, np.int32)[[]], (255, 255, 0))
    image = cv.addWeighted(img, round(random.uniform(0.03, 0.28), 2), mask_img, 1, 0)  # 里面参数可调，主要调整雾的浓度
    #
    cv.imwrite('C:/Users/Lee/Desktop/train_update/img_create/' + file_img, image)  # 保存的文件夹