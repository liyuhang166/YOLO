from __future__ import print_function

from math import log10
from YOLO_FDM import YOLO_FDM
from utils.torch_utils import *
from utils.datasets import create_dataloader
from utils.general import *
from tqdm import tqdm

init_seeds(1)


# --------------------定义训练函数--------------------
def Train_YOLO_FDM(train_path1, train_path2, batch_size, epochs):
    # -----------------加载数据----------------
    imgsz = 640
    gs = 32
    rank = -1
    hyp = {
        'lr0': 0.01, 'lrf': 0.2, 'momentum': 0.937, 'weight_decay': 0.0005,
        'warmup_epochs': 3.0, 'warmup_momentum': 0.8, 'warmup_bias_lr': 0.1,
        'box': 0.05, 'cls': 0.5, 'cls_pw': 1.0, 'obj': 1.0, 'obj_pw': 1.0, 'iou_t': 0.2,
        'anchor_t': 4.0, 'fl_gamma': 0.0, 'hsv_h': 0.015, 'hsv_s': 0.7, 'hsv_v': 0.4,
        'degrees': 0.0, 'translate': 0.1, 'scale': 0.5, 'shear': 0.0, 'perspective': 0.0,
        'flipud': 0.0, 'fliplr': 0.5, 'mosaic': 1.0, 'mixup': 0.0
    }
    opt = {
        'weights': 'runs/train/exp10/weights/best.pt',
        'cfg': 'models/yolov5s_hat.yaml',
        'data': 'data/clean.yaml',
        'hyp': hyp, 'epochs': 1, 'batch_size': 1, 'img_size': [640, 640],
        'rect': False, 'resume': False, 'nosave': False, 'notest': False, 'noautoanchor': False, 'evolve': False,
        'bucket': '',
        'cache_images': False, 'image_weights': False, 'device': '', 'multi_scale': False, 'single_cls': False,
        'adam': False, 'sync_bn': False,
        'local_rank': -1, 'workers': 8, 'project': 'runs/train', 'entity': None, 'name': 'exp', 'exist_ok': False,
        'quad': False, 'linear_lr': False, 'label_smoothing': 0.0,
        'upload_dataset': False, 'bbox_interval': -1, 'save_period': -1, 'artifact_alias': 'latest', 'world_size': 1,
        'global_rank': -1, 'save_dir': 'runs\\train\\exp5',
        'total_batch_size': 1
    }

    dataloader1, dataset1 = create_dataloader(train_path1, imgsz, batch_size, gs, opt,
                                              hyp=hyp, augment=True, cache=False, rect=False, rank=rank,
                                              world_size=1, workers=8,
                                              image_weights=False, quad=False, prefix=colorstr('train: '))
    nb1 = len(dataloader1)
    pbar1 = enumerate(dataloader1)
    if rank in [-1, 0]:
        pbar1 = tqdm(pbar1, total=nb1)  # progress bar

    dataloader2, dataset2 = create_dataloader(train_path2, imgsz, batch_size, gs, opt,
                                              hyp=hyp, augment=True, cache=False, rect=False, rank=rank,
                                              world_size=1, workers=8,
                                              image_weights=False, quad=False, prefix=colorstr('train: '))
    nb2 = len(dataloader2)
    pbar2 = enumerate(dataloader2)
    if rank in [-1, 0]:
        pbar2 = tqdm(pbar2, total=nb2)  # progress bar

    # 低质量图像
    low_images = []
    for i, (imgs, targets, paths, _) in pbar1:  # batch
        imgs = imgs.to(device='cpu', non_blocking=True).float() / 255.0  # uint8 to float32, 0-255 to 0.0-1.0
        low_images.append(imgs)

    # 高质量图像
    high_images = []
    for i, (imgs, targets, paths, _) in pbar2:  # batch
        imgs = imgs.to(device='cpu', non_blocking=True).float() / 255.0  # uint8 to float32, 0-255 to 0.0-1.0
        high_images.append(imgs)

    # 声明网络模型
    YOLO_FDM_Net = YOLO_FDM()
    MSE_loss = nn.MSELoss(reduce=True, size_average=True)  # 选择损失函数
    optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, YOLO_FDM_Net.parameters()), lr=0.001)  # 选择优化器
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)  # 设置学习率下降策略

    train_loss = []
    # --------------------训练-------------------
    for epoch in range(epochs):
        YOLO_FDM_Net.train()
        scheduler.step()  # 更新学习率
        for i in range(0, 59):
            # 获取低质量图像、高质量图像
            low_input = low_images[i]
            high_input = high_images[i]
            # 优化器梯度初始化为零
            optimizer.zero_grad()
            # 前向传播，返回增强低质量浅层特征和原始高质量浅层特征
            FDM_Low_Feature, High_Feature = YOLO_FDM_Net(low_input, high_input)
            loss = MSE_loss(FDM_Low_Feature, High_Feature)
            loss.backward()
            optimizer.step()
            mse = loss
            psnr = 10 * log10(1 / mse.item())
            # 保存损失
            train_loss.append(loss.item())
            # 保存最小损失模型
            minloss = min(train_loss)
            if loss.item() <= minloss:
                torch.save(YOLO_FDM_Net, 'FDM_best.pt')
            print(
                "Training: Epoch[{:0>3}/{:0>3}] Iteration[{:0>3}/{:0>3}] Loss: {:.4f} MSE: {:.4f} PSNR: {:.4f}DB".format(
                    epoch + 1, epochs, i + 1, len(low_images), loss.item(), mse.item(), psnr))
        if (epoch + 1) % 10 == 0:
            torch.save(YOLO_FDM_Net, 'FDM_last.pt')


if __name__ == '__main__':
    train_path1 = 'data/images/train'  # 低质量图像
    train_path2 = 'data/images/val'  # 高质量图像
    epoch = 100
    batch_size = 3
    print("FDM after Focus and Conv")
    Train_YOLO_FDM(train_path1, train_path2, batch_size, epoch)
