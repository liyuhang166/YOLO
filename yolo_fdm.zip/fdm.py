import torch
import torch.nn as nn
import torch.nn.functional as F


class Concat(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, dimension=1):
        super(Concat, self).__init__()
        self.d = dimension

    def forward(self, x):
        return torch.cat(x, self.d)


# 定义FDM增强模块
class FDM(nn.Module):
    def __init__(self):
        super(FDM, self).__init__()

        # 定义BB层
        self.BB = nn.Sequential(nn.Conv2d(32, 64, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(64), nn.ReLU())
        # 定义E1层
        self.E1 = nn.Sequential(nn.Conv2d(64, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU(),
                                nn.MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1))
        # 定义E2层
        self.E2 = nn.Sequential(nn.Conv2d(16, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU(),
                                nn.MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1))
        # 定义E3层
        self.E3 = nn.Sequential(nn.Conv2d(16, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU())
        # 定义W层
        self.W = nn.Sequential(nn.Conv2d(16, 16, kernel_size=3, padding=1, dilation=2), nn.BatchNorm2d(16), nn.ReLU())
        # 定义D1层
        self.D1 = nn.Sequential(nn.Conv2d(32, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU())
        # 定义D2层
        self.D2 = nn.Sequential(nn.Conv2d(32, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(64), nn.ReLU())
        # 定义D3层
        self.D3 = nn.Sequential(nn.Conv2d(32, 64, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(64), nn.ReLU())
        # 定义CC层
        self.CC = nn.Sequential(nn.Conv2d(64, 32, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(64), nn.ReLU())

    # FeaLow是浅层特征，img_Low是原始特征
    def forward(self, FeaLow):
        assert FeaLow.size()[1] == 32

        x1 = self.BB(FeaLow)
        x2 = self.E1(x1)
        x3 = self.E2(x2)
        x4 = self.E3(x3)
        x5 = self.W(x4)
        x6 = Concat(x4, x5)  # 32
        x7 = self.D1(x6)  # 16
        x8 = Concat(x3, x7)  # 32
        x9 = self.D2(x8)  # 16
        x10 = Concat(x2, x9)  # 32
        x11 = self.D3(x10)
        x12 = x1 + x11
        x13 = self.CC(x12)
        x14 = FeaLow + x13

        return x14

