from __future__ import print_function

from attention_model.attention.SKAttention import SKAttention
from models.yolo import Model
from utils.torch_utils import *
# 加载YOLOv5模型
from models.experimental import attempt_load


# 定义FDM增强模块
class FDM(nn.Module):
    def __init__(self):
        super(FDM, self).__init__()
        # 定义BB层
        self.BB = nn.Sequential(nn.Conv2d(32, 64, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(64), nn.ReLU())
        # 定义E1层
        self.E1 = nn.Sequential(nn.Conv2d(64, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU(),
                                nn.MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1))
        # 定义E2层
        self.E2 = nn.Sequential(nn.Conv2d(16, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU(),
                                nn.MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1))
        # 定义E3层
        self.E3 = nn.Sequential(nn.Conv2d(16, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU())
        # 定义W层
        self.W = nn.Sequential(nn.Conv2d(16, 16, kernel_size=3, padding=2, dilation=2), nn.BatchNorm2d(16), nn.ReLU())
        # 定义D1层
        self.D1 = nn.Sequential(nn.Conv2d(32, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU())
        # 定义D2层
        self.D2 = nn.Sequential(nn.Conv2d(32, 16, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(16), nn.ReLU(),
                                nn.Upsample(scale_factor=2))
        # 定义D3层
        self.D3 = nn.Sequential(nn.Conv2d(32, 64, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(64), nn.ReLU(),
                                nn.Upsample(scale_factor=2))
        # 定义CC层
        self.CC = nn.Sequential(nn.Conv2d(64, 32, kernel_size=3, padding=1, dilation=1), nn.BatchNorm2d(32), nn.ReLU())

    # FeaLow是浅层特征，img_Low是原始特征
    def forward(self, FeaLow):
        assert FeaLow.size()[1] == 32

        x1 = self.BB(FeaLow)
        x2 = self.E1(x1)
        x3 = self.E2(x2)
        x4 = self.E3(x3)
        x5 = self.W(x4)
        x6 = torch.cat((x4, x5), 1)  # 32
        x7 = self.D1(x6)  # 16
        x8 = torch.cat((x3, x7), 1)  # 32
        x9 = self.D2(x8)  # 16
        x10 = torch.cat((x2, x9), 1)  # 32
        x11 = self.D3(x10)
        x12 = x1 + x11
        x13 = self.CC(x12)
        x14 = FeaLow + x13

        return x14


# 定义YOLO_FDM网络
class YOLO_FDM(nn.Module):
    def __init__(self):
        super(YOLO_FDM, self).__init__()
        # -------------YOLOV5---------------------
        # 加载YOLOV5模型
        ckpt = torch.load('runs/train/exp10/weights/best.pt', map_location='cpu')  # load checkpoint
        # 加载网络结构，定义网络（包括YOLO浅层和FDM模块）
        cfg = 'models/yolov5s_hat.yaml'
        anchors = None
        resume = False
        model = Model(cfg or ckpt['model'].yaml, ch=3, nc=1, anchors=anchors).to('cpu')  # create
        exclude = ['anchor'] if (cfg or anchors) and not resume else []  # exclude keys
        state_dict = ckpt['model'].float().state_dict()  # to FP32
        state_dict = intersect_dicts(state_dict, model.state_dict(), exclude=exclude)  # intersect
        model.load_state_dict(state_dict, strict=False)  # load
        yolo_layers = nn.ModuleList(model.children())
        # 参数固定
        for k, v in model.named_parameters():
            v.requires_grad = False  # train all layers
        # 定义结构，backbone
        self.Focus = yolo_layers[0][0]
        self.Conv_1 = yolo_layers[0][1]
        self.C3_1 = yolo_layers[0][2]
        self.Conv_2 = yolo_layers[0][3]
        self.C3_2 = yolo_layers[0][4]
        self.Conv_3 = yolo_layers[0][5]
        self.C3_3 = yolo_layers[0][6]
        self.Conv_4 = yolo_layers[0][7]
        self.SPP = yolo_layers[0][8]
        self.C3_4 = yolo_layers[0][9]
        # 定义结构，Head
        self.Conv_5 = yolo_layers[0][10]
        self.Unsample_1 = yolo_layers[0][11]
        self.Concat_1 = yolo_layers[0][12]
        self.C3_5 = yolo_layers[0][13]
        self.Conv_6 = yolo_layers[0][14]
        self.Unsample_2 = yolo_layers[0][15]
        self.Concat_2 = yolo_layers[0][16]
        self.C3_6 = yolo_layers[0][17]
        self.Conv_7 = yolo_layers[0][18]
        self.Concat_3 = yolo_layers[0][19]
        self.C3_7 = yolo_layers[0][20]
        self.Conv_8 = yolo_layers[0][21]
        self.Concat_4 = yolo_layers[0][22]
        self.C3_8 = yolo_layers[0][23]
        self.Detect = yolo_layers[0][24]
        # -------------FDM---------------------
        self.FDM = FDM()

    def forward(self, low, high):
        # 高质量图像经过一层卷积，得到的浅层特征
        high_feature = self.Focus(high)
        # 低质量图像经过一层卷积，得到的浅层特征
        low_feature = self.Focus(low)
        # 低质量浅层增强
        enh_feature = self.FDM(low_feature)

        # 返回低质量增强后的特征，和高质量图像浅层特征
        return enh_feature, high_feature

    def test_forward(self, x):
        # Backbone
        x_feature0 = self.Focus(x)

        # FDM增强
        self.FDM.eval()
        x_feature1 = self.FDM(x_feature0)

        x_feature2 = self.Conv_1(x_feature1)
        x_feature3 = self.C3_1(x_feature2)
        x_feature4 = self.Conv_2(x_feature3)
        x_feature5 = self.C3_2(x_feature4)
        x_feature6 = self.Conv_3(x_feature5)
        x_feature7 = self.C3_3(x_feature6)
        x_feature8 = self.Conv_4(x_feature7)
        x_feature9 = self.SPP(x_feature8)
        x_feature10 = self.C3_4(x_feature9)
        # Head
        x_feature11 = self.Conv_5(x_feature10)
        x_feature12 = self.Unsample_1(x_feature11)
        x_feature13 = self.Concat_1((x_feature12, x_feature7))
        x_feature14 = self.C3_5(x_feature13)
        x_feature15 = self.Conv_6(x_feature14)
        x_feature16 = self.Unsample_2(x_feature15)
        x_feature17 = self.Concat_2((x_feature16, x_feature5))
        x_feature18 = self.C3_6(x_feature17)
        x_feature19 = self.Conv_7(x_feature18)
        x_feature20 = self.Concat_3((x_feature19, x_feature15))
        x_feature21 = self.C3_7(x_feature20)
        x_feature22 = self.Conv_8(x_feature21)
        x_feature23 = self.Concat_4((x_feature22, x_feature11))
        x_feature24 = self.C3_8(x_feature23)
        x_feature25 = self.Detect((x_feature18, x_feature21, x_feature24))

        return x_feature25

    def test_forward1(self, x):
        # Backbone
        x_feature0 = self.Focus(x)
        x_feature1 = self.Conv_1(x_feature0)
        x_feature2 = self.C3_1(x_feature1)
        x_feature3 = self.Conv_2(x_feature2)
        x_feature4 = self.C3_2(x_feature3)
        x_feature5 = self.Conv_3(x_feature4)
        x_feature6 = self.C3_3(x_feature5)
        x_feature7 = self.Conv_4(x_feature6)
        x_feature8 = self.SPP(x_feature7)
        x_feature9 = self.C3_4(x_feature8)
        # Head
        x_feature10 = self.Conv_5(x_feature9)
        x_feature11 = self.Unsample_1(x_feature10)
        x_feature12 = self.Concat_1((x_feature11, x_feature6))
        x_feature13 = self.C3_5(x_feature12)
        x_feature14 = self.Conv_6(x_feature13)
        x_feature15 = self.Unsample_2(x_feature14)
        x_feature16 = self.Concat_2((x_feature15, x_feature4))
        x_feature17 = self.C3_6(x_feature16)
        x_feature18 = self.Conv_7(x_feature17)
        x_feature19 = self.Concat_3((x_feature18, x_feature14))
        x_feature20 = self.C3_7(x_feature19)
        x_feature21 = self.Conv_8(x_feature20)
        x_feature22 = self.Concat_4((x_feature21, x_feature10))
        x_feature23 = self.C3_8(x_feature22)
        x_feature24 = self.Detect((x_feature17, x_feature20, x_feature23))

        return x_feature24
