from __future__ import print_function


from utils.general import *
from utils.plots import *
from utils.datasets import *


init_seeds(1)



def Test_YOLO_FDM(source, ModelPath, save_img=False, view_img=False):
    batch_size = 1

    # ------------------------------------ 1.加载数据------------------------------------
    # 加载数据
    dataset = LoadImages(source, img_size=640, stride=32)

    half = False
    names = ['vehicle']
    colors = [[218, 227, 42]]

    # 加载模型
    YOLO_FDM_Net = torch.load(ModelPath)
    YOLO_FDM_Net.eval()

    for path, img, im0s, vid_cap in dataset:
        img = torch.from_numpy(img).to('cpu')
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        if img.ndimension() == 3:
            img = img.unsqueeze(0)

        pred = YOLO_FDM_Net.test_forward(img)[0]
        # Apply NMS
        pred = non_max_suppression(pred, 0.25, 0.45,  classes=None, agnostic=False)

        webcam = False
        save_dir = 'C:/Users/Lee/Desktop/train_update/img_result/YOLO_FDM'
        save_txt = False
        # Process detections
        for i, det in enumerate(pred):  # detections per image
            if webcam:  # batch_size >= 1
                p, s, im0, frame = path[i], '%g: ' % i, im0s[i].copy(), dataset.count
            else:
                p, s, im0, frame = path, '', im0s, getattr(dataset, 'frame', 0)

            p = Path(p)  # to Path
            save_path = save_dir + '/' + p.name  # img.jpg
            txt_path = save_dir + '/' + 'labels' + p.stem + ('' if dataset.mode == 'image' else f'_{frame}')  # img.txt
            s += '%gx%g ' % img.shape[2:]  # print string
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh

            if len(det):
                # Rescale boxes from img_size to im0 size
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                # Print results
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string

                # Write results
                for *xyxy, conf, cls in reversed(det):
                    if save_img or view_img:  # Add bbox to image
                        label = f'{names[int(cls)]} {conf:.2f}'
                        plot_one_box(xyxy, im0, label=label, color=colors[int(cls)], line_thickness=3)

            # Stream results
            if view_img:
                cv2.imshow(str(p), im0)
                cv2.waitKey(1)  # 1 millisecond

            # Save results (image with detections)
            if save_img:
                if dataset.mode == 'image':
                    cv2.imwrite(save_path, im0)

    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        print(f"Results saved to {save_dir}{s}")

def Test_YOLO(source, ModelPath, save_img=False, view_img=False):
    batch_size = 1

    # ------------------------------------ 1.加载数据------------------------------------
    # 加载数据
    dataset = LoadImages(source, img_size=640, stride=32)

    half = False
    names = ['vehicle']
    colors = [[218, 227, 42]]

    # 加载模型
    YOLO_FDM_Net = torch.load(ModelPath)
    YOLO_FDM_Net.eval()

    for path, img, im0s, vid_cap in dataset:
        img = torch.from_numpy(img).to('cpu')
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        if img.ndimension() == 3:
            img = img.unsqueeze(0)

        pred = YOLO_FDM_Net.test_forward1(img)[0]
        # Apply NMS
        pred = non_max_suppression(pred, 0.25, 0.45,  classes=None, agnostic=False)

        webcam = False
        save_dir = 'C:/Users/Lee/Desktop/train_update/img_result/YOLO'
        save_txt = False
        # Process detections
        for i, det in enumerate(pred):  # detections per image
            if webcam:  # batch_size >= 1
                p, s, im0, frame = path[i], '%g: ' % i, im0s[i].copy(), dataset.count
            else:
                p, s, im0, frame = path, '', im0s, getattr(dataset, 'frame', 0)

            p = Path(p)  # to Path
            save_path = save_dir + '/' + p.name  # img.jpg
            txt_path = save_dir + '/' + 'labels' + p.stem + ('' if dataset.mode == 'image' else f'_{frame}')  # img.txt
            s += '%gx%g ' % img.shape[2:]  # print string
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh

            if len(det):
                # Rescale boxes from img_size to im0 size
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                # Print results
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string

                # Write results
                for *xyxy, conf, cls in reversed(det):
                    if save_img or view_img:  # Add bbox to image
                        label = f'{names[int(cls)]} {conf:.2f}'
                        plot_one_box(xyxy, im0, label=label, color=colors[int(cls)], line_thickness=3)

            # Stream results
            if view_img:
                cv2.imshow(str(p), im0)
                cv2.waitKey(1)  # 1 millisecond

            # Save results (image with detections)
            if save_img:
                if dataset.mode == 'image':
                    cv2.imwrite(save_path, im0)

    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        print(f"Results saved to {save_dir}{s}")


if __name__ == '__main__':
    source = 'data/images/train'
    print("Test YOLO_FDM in YOLO_FDM_best.pt")

    Test_YOLO_FDM(source, './FDM_last.pt', save_img=True, view_img=False)
    # Test_YOLO(source, './FDM_last.pt', save_img=True, view_img=False)
